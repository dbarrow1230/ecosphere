// Preserve older imports while using the single supply inventory form.
export {default} from "../../supplies/SuppliesPage.jsx";
